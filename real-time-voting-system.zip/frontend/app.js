angular.module('VotingApp', [])
  .controller('VotingController', function($scope, $http) {
    const API = 'http://localhost:3000';

    $scope.loggedIn = false;
    $scope.elections = [];
    $scope.candidates = [];
    $scope.results = [];

    $scope.register = function() {
      $http.post(API + '/register', {
        username: $scope.username,
        password: $scope.password
      }).then(res => alert(res.data.message));
    };

    $scope.login = function() {
      $http.post(API + '/login', {
        username: $scope.username,
        password: $scope.password
      }).then(res => {
        alert(res.data.message);
        $scope.loggedIn = true;
        $scope.getElections();
      }, err => alert(err.data.message));
    };

    $scope.getElections = function() {
      $http.get(API + '/elections').then(res => {
        $scope.elections = res.data;
      });
    };

    $scope.getCandidates = function(election_id) {
      $http.get(API + '/candidates/' + election_id).then(res => {
        $scope.candidates = res.data;
        $scope.getResults(election_id);
      });
    };

    $scope.vote = function(candidate_id) {
      $http.post(API + '/vote', {
        user_id: 1,
        candidate_id: candidate_id
      }).then(res => {
        alert(res.data.message);
        $scope.getResults($scope.selectedElection.id);
      });
    };

    $scope.getResults = function(election_id) {
      $http.get(API + '/results/' + election_id).then(res => {
        $scope.results = res.data;
      });
    };
  });
