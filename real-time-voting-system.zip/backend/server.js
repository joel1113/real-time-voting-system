const express = require('express');
const mysql = require('mysql');
const bodyParser = require('body-parser');
const cors = require('cors');
const app = express();
const port = 3000;

app.use(cors());
app.use(bodyParser.json());

const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'voting_system'
});

db.connect(err => {
  if (err) throw err;
  console.log('Connected to MySQL');
});

app.post('/register', (req, res) => {
  const { username, password } = req.body;
  const sql = 'INSERT INTO users (username, password) VALUES (?, ?)';
  db.query(sql, [username, password], (err, result) => {
    if (err) return res.status(500).send(err);
    res.send({ message: 'User registered successfully' });
  });
});

app.post('/login', (req, res) => {
  const { username, password } = req.body;
  const sql = 'SELECT * FROM users WHERE username = ? AND password = ?';
  db.query(sql, [username, password], (err, results) => {
    if (err) return res.status(500).send(err);
    if (results.length > 0) {
      res.send({ message: 'Login successful' });
    } else {
      res.status(401).send({ message: 'Invalid credentials' });
    }
  });
});

app.get('/elections', (req, res) => {
  db.query('SELECT * FROM elections', (err, results) => {
    if (err) return res.status(500).send(err);
    res.send(results);
  });
});

app.get('/candidates/:election_id', (req, res) => {
  const { election_id } = req.params;
  db.query('SELECT * FROM candidates WHERE election_id = ?', [election_id], (err, results) => {
    if (err) return res.status(500).send(err);
    res.send(results);
  });
});

app.post('/vote', (req, res) => {
  const { user_id, candidate_id } = req.body;
  const sql = 'INSERT INTO votes (user_id, candidate_id) VALUES (?, ?)';
  db.query(sql, [user_id, candidate_id], (err, result) => {
    if (err) return res.status(500).send(err);
    res.send({ message: 'Vote cast successfully' });
  });
});

app.get('/results/:election_id', (req, res) => {
  const { election_id } = req.params;
  const sql = `
    SELECT c.name, COUNT(v.id) AS votes 
    FROM candidates c 
    LEFT JOIN votes v ON c.id = v.candidate_id 
    WHERE c.election_id = ? 
    GROUP BY c.id
  `;
  db.query(sql, [election_id], (err, results) => {
    if (err) return res.status(500).send(err);
    res.send(results);
  });
});

app.listen(port, () => {
  console.log(\`Server running on http://localhost:\${port}\`);
});
